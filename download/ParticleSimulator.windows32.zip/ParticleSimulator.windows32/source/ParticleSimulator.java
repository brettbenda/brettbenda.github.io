import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ParticleSimulator extends PApplet {

/*
Made in 2017 by Brett Benda
*/
ArrayList<ForceField> forces = new ArrayList<ForceField>();
ArrayList<ParticleSystem> systems = new ArrayList<ParticleSystem>();
ArrayList<String> buttonNames = new ArrayList<String>();
boolean buttonHasBeenPressed = false;
UI ui;

int iC=1;
boolean isCapturing = false;
public void setup() {
  
  background(255);
  textFont(createFont("Tahoma", 10));

  //add button names to the list, and generate the UI
  buttonNames.add("Gravity");
  buttonNames.add("Radial");
  buttonNames.add("Newton");
  buttonNames.add("System");
  buttonNames.add("Clear");
  ui = new UI(buttonNames);
}

public void draw() {
  textFont(createFont("Tahoma", 10));
  background(255);

  updateSystems();
  updateForces();
  performClickOperation();
  showEverything();
  
  if(isCapturing && iC<=150){
       save("particle" + nf(iC,4) + ".jpg");
       iC++;
  }else{
     isCapturing = false;
     iC=1;
  }
}

public void keyPressed(){
  if(key=='p'){
    isCapturing = true;
  }
}

//if a button on the UI has been pressed, we perform the desired action
public void performClickOperation() {
  //get the current info from the ui
  String op = ui.getClickedButton();

  //checks when button has been released
  if (op.equals("none")) {
    buttonHasBeenPressed = false;
  }

  //if button is not pressed, check if one has been and perform action by getting data from the UI
  if (!buttonHasBeenPressed) {
    switch(op) {
    case "Newton":
      buttonHasBeenPressed = true;
      forces.add(new NewtonField(new Point(width/2, height/2), ui.newtMag.getData()));
      addNewForceToAllSystems();
      break;
    case "Radial":
      buttonHasBeenPressed = true;
      forces.add(new RadialField(new Point(width/2, height/2), ui.radMag.getData()));
      addNewForceToAllSystems();
      break;
    case "Gravity":
      buttonHasBeenPressed = true;
      forces.add(new GravityField(ui.gravMag.getData(), ui.direction.getData()));
      addNewForceToAllSystems();
      break;
    case "System":
      buttonHasBeenPressed = true;
      systems.add(new ParticleSystem(new SystemSettings(new Point(width/2, height/2), 
        (int)ui.numberOfParticles.getData(), 
        ui.maxXVel.getData(), 
        ui.minXVel.getData(), 
        ui.maxYVel.getData(), 
        ui.minYVel.getData(), 
        ui.particleType.getData())));
      addAllForcesToNewSystem();
      break;
    case "Clear":
      buttonHasBeenPressed = true;
      systems.clear();
      forces.clear();
    }
  }
}

//adds all existing forces to a system that has just been generated
public void addAllForcesToNewSystem() {
  for (int i = 0; i < forces.size(); i++) {
    systems.get(systems.size()-1).addForce(forces.get(i));
  }
}

//adds a new force to all systems that have already been generated
public void addNewForceToAllSystems() {
  for (int i = 0; i < systems.size(); i++) {
    systems.get(i).addForce(forces.get(forces.size()-1));
  }
}

public void updateForces() {
  for (int i = 0; i < forces.size(); i++) {
    if (forces.get(i).isRightClicked()) {
      forces.remove(i);
      for (int j = 0; j < systems.size(); j++) {
        systems.get(j).forces.clear();
        for (int k = 0; k < forces.size(); k++) {
          systems.get(j).addForce(forces.get(k));
        }
      }
    }
  }
}

//updated particle info for all systems
public void updateSystems() {
  for (int i = 0; i < systems.size(); i++) {
    systems.get(i).update();
    if (systems.get(i).isRightClicked()) {
      systems.remove(i);
    }
  }
}

//displays all the graphics for the current state of the program
public void showEverything() {
  textFont(createFont("Tahoma", 10));
  for (int i = 0; i < systems.size(); i++) {
    systems.get(i).show();
  }
  for (int i = 0; i < forces.size(); i++) {
    forces.get(i).show();
  }
  ui.show();
}
class Button {
  float x;
  float y;
  float buttonWidth;
  float buttonHeight;
  String name;

  Button(float x, float y, float buttonWidth, float buttonHeight, String name) {
    this.x=x;
    this.y=y;
    this.buttonWidth=buttonWidth;
    this.buttonHeight=buttonHeight;
    this.name = name;
  }

  public void show() {
    rectMode(CENTER);
    if (isClicked()) {
      fill(200);
    } else {
      fill(225);
    }
    stroke(100);
    rect(x, y, buttonWidth, buttonHeight, 10);
    fill(0);
    textFont(createFont("Tahoma", buttonHeight/2));
    textAlign(CENTER);
    text(name,x,y+buttonHeight/5);
  }

  public boolean isClicked() {
    if (mousePressed && isOver()) {
      return true;
    }
    return false;
  }

  public boolean isOver() {
    if (mouseX > x - buttonWidth/2 && mouseX < x + buttonWidth/2) {
      if (mouseY > y - buttonHeight/2 && mouseY < y + buttonHeight/2) {
        return true;
      }
    }
    return false;
  }
}
class DataInput {
  float data = 0; //current value that can be retrieved
  float x, y, upperBound, lowerBound, increment; //x coord of center, y coord of center, max value, min value, value used as increment
  String name; //name of the field
  Button upper, lower; //buttons to modify the current data
  boolean hasBeenClicked = false; //by default, neither button is clicked

  DataInput(String name, float defaultVal, float x, float y, float upperBound, float lowerBound, float increment) {
    this.name = name;
    this.data = defaultVal;
    this.x = x;
    this.y = y;
    this.upperBound = upperBound;
    this.lowerBound = lowerBound;
    this.lower = new Button(x-50,y,25,25,"-");
    this.upper = new Button(x+50,y,25,25,"+");
    this.increment = increment;
  }
  
  public void show(){
   //increment data by the given increment value if the right arrow is selected
   if(upper.isClicked() && data < upperBound && !hasBeenClicked){
    data+=increment; 
    hasBeenClicked = true;
   }
   //decrement data by the given increment value if the left arrow is selected
   if(lower.isClicked() && data > lowerBound && !hasBeenClicked){
    data-= increment; 
    hasBeenClicked = true;
   }
   
   //if neither button is clicked, neither has been clicked
   if(!upper.isClicked() && !lower.isClicked()){
    hasBeenClicked = false; 
   }
   
   //display data
   lower.show();
   upper.show();
   textFont(createFont("Tahoma", width/50));
   textAlign(CENTER,CENTER);
   if(data%1==0){
     text((int)data,x,y);
   }else{
     text(data,x,y);
   }
   text(name,x,y-height/40);
  }
  
  
  //return the data currently being stored
  public float getData(){
   return this.data; 
  }
}
class ForceField{
  //all will have a point containing the velocity
  Point velocity;
  
  //all will take in a point to return a velocity value
  public Point getVelocity(Point point){ return velocity; }
  
  public void show(){};
  
  public boolean isRightClicked(){ return false; }
}
//creates a force field that applies a force evenly in a certain,
//static direction
class GravityField extends ForceField {
  //mag contains the magnitude of the force
  float mag;
  //dir contains the direction
  String dir;

  GravityField(float mag, String dir) {
    this.dir = dir; 
    this.mag = mag;

    //these assign velocity with the correct combination of zero and mag
    switch(dir) {
    case "DOWN":
      velocity = new Point(0, mag); 
      break;
    case "UP":
      velocity = new Point(0, -mag); 
      break;
    case "RIGHT":
      velocity = new Point(-mag, 0); 
      break;
    case "LEFT":
      velocity = new Point(mag, 0);
      break;
    }
  }

  //straight-up returns the velocity point
  public Point getVelocity(Point point) { 
    return velocity;
  }

  //display details in top corner
  public void show() {
    fill(0);
    textAlign(CENTER);
    //displays value in top right corner
    text("G: " + mag + " " + dir, 50, 25);
  }

  public boolean isRightClicked() {
    if (mouseX > 0 && mouseX < 100) {
      if (mouseY > 0 && mouseY < 100) {
        if (mousePressed && mouseButton == RIGHT) {
          return true;
        }
      }
    }
    return false;
  }
}
//this system simulates Newton's Law of Universal Gravitation

class NewtonField extends ForceField {
  Point center; //where the force is coming from
  float mag; //the magnitude of the force
  boolean isMoving = false; //if the force is clicked on to move

  NewtonField(Point center, float mag) {
    this.center = new Point(center.getX(),center.getY());
    this.mag = mag;
  }

  public Point getVelocity(Point point) {
    float dx = center.getX() - point.getX(); //change in x
    float dy = center.getY() - point.getY(); //change in y
    float dist = dist(center.getX(),center.getY(),point.getX(),point.getY()); //distance between the field source and particle
    float angle = atan(dy/dx); //angle between field source and particle
    
    
    //if dx is negative, we want to negate the return values
    if (dx<0) {
      return new Point(-mag*cos(angle)/pow(dist/10,2), -mag*sin(angle)/pow(dist/10,2));
    } else { //return normal values
      return new Point(mag*cos(angle)/pow(dist/10,2), mag*sin(angle)/pow(dist/10,2));
    }
  }

  public void show() {
    //if is clicked, move to mouse 
    if (isLeftClicked()) {
      isMoving = true;
    }
    if(!mousePressed){
     isMoving = false; 
    }
    if(isMoving){
     center.setX(mouseX);
     center.setY(mouseY); 
    }

    //draw identifiers
    fill(0,200);
    stroke(0);
    ellipse(center.getX(), center.getY(), 50, 50); 
    
    fill(255);
    textAlign(CENTER);
    text("N\n" + mag, center.getX(), center.getY()-5);
  }

  public boolean isLeftClicked() {
    if (isOver() && mousePressed && mouseButton == LEFT) {
      return true;
    }
    return false;
  }
  
  public boolean isRightClicked() {
    if (isOver() && mousePressed && mouseButton == RIGHT) {
      return true;
    }
    return false;
  }

  public boolean isOver() {
    if (dist(center.getX(), center.getY(),mouseX,mouseY) < 25) {
      return true;
    }
    return false;
  }
}
class Particle {
  Point current; //current x and y location
  Point old; //previous x and y location
  Point velocity; //current velocity
  String type;

  Particle() {
  }

  Particle(Point current, Point velocity, String type) {
    this.current = current;
    this.old = new Point(current.getX(), current.getY()); //do not want same reference
    this.velocity = velocity;
    this.type = type;
  }

  public void show() {
    switch(type) {
    case "LINE":
      strokeWeight(1);
      //draw line between old and current point
      line(current.getX(), current.getY(), old.getX(), old.getY()); 
      break;
    case "CIRCLE":
      noStroke();
      fill(0);
      ellipse(current.getX(), current.getY(), 5, 5);
      break;
    }
  }

  public void update(ArrayList<ForceField> forces) {

    float dx = 0; //change in x velocity
    float dy = 0; //change in y velocity

    for (int i = 0; i<forces.size(); i++) {
      dx += forces.get(i).getVelocity(this.current).getX(); //sum x forces of all ForceFields
      dy += forces.get(i).getVelocity(this.current).getY(); //sum y forces of all ForceFields
    }

    //update old location point 
    old.setX(current.getX());
    old.setY(current.getY());

    //update current location point
    current.setX(current.getX() + velocity.getX());
    current.setY(current.getY() + velocity.getY());

    //update velocity to be updated next iteration
    velocity.setX(velocity.getX() + dx);
    velocity.setY(velocity.getY() + dy);
  }

  public boolean isOutOfBounds() {
    if ((current.getX() < 0 || current.getX() > width) && (old.getX() < 0 || old.getX() > width)) {
      return true;
    }
    
    //for y, we must subtract the height of the UI on the bottom
    if ((current.getY() < 0 || current.getY() > height-2*height/9) && (old.getY() < 0 || old.getY() > height-2*height/9)) {
      return true;
    }
    return false;
  }
}
class ParticleSystem{
 SystemSettings settings; //base settings for particle generation
 int numberOfParticles; //number that will exist at a given time
 Point center; //location of emitter
 ArrayList<ForceField> forces = new ArrayList<ForceField>(); //all the forces applied to the system
 Particle[] system; //the array of particles
 boolean isMoving; //if the system is clicked on to move
 
 ParticleSystem(SystemSettings settings){
   this.settings = settings;
   this.center = settings.center();
   this.numberOfParticles = settings.particleCount();
   this.system = new Particle[numberOfParticles];
   
   initialize();
 }
 
 //return a new particle
 public Particle generateNewParticle(){
   return new Particle(new Point(center.getX(),center.getY()),new Point(random(settings.minXVelocity(),settings.maxXVelocity()),random(settings.minYVelocity(),settings.maxYVelocity())),settings.particleType);
 }
 
 //initializes all particles at beginning of program
 public void initialize(){
   for(int i = 0; i<numberOfParticles; i++){
    system[i] = generateNewParticle();
   }
 }
 
 //draws the emitter, with details
 public void show(){
   fill(255);
   stroke(0);
   ellipse(center.getX(),center.getY(),50,50);
   
   fill(0);
   textAlign(CENTER);
   text("P\n" + numberOfParticles,center.getX(),center.getY());
   for(int i = 0; i<numberOfParticles; i++){
    system[i].show();
   }
 }
 
 //updates info for all particles, and location of emitter if it is clicked
 public void update(){
    if (isLeftClicked()) {
      isMoving = true;
    }
    if(!mousePressed){
     isMoving = false; 
    }
    if(isMoving){
     center.setX(mouseX);
     center.setY(mouseY); 
    }
   
   for(int i = 0; i<numberOfParticles; i++){
    if(system[i].isOutOfBounds()){
       system[i] = generateNewParticle();
    }else{
       system[i].update(forces);
    }
   }
 }
 
 public boolean isLeftClicked(){
  if(isOver() && mousePressed && mouseButton == LEFT){
   return true; 
  }
  return false;
 }
 
 public boolean isRightClicked() {
    if (isOver() && mousePressed && mouseButton == RIGHT) {
      return true;
    }
    return false;
  }
 
 public boolean isOver(){
  if(dist((float)mouseX,(float)mouseY,center.getX(),center.getY()) < 25){
    return true;
  }
  return false;
 }
 
 //add force to list of forces acting on the system
 public void addForce(ForceField newField){
   forces.add(newField);
 }
}
class Point{
 float x,y;
 
 Point(){ }

 Point(float x, float y){
  setX(x);
  setY(y);
 }
 
 public void setX(float x){ this.x = x; }
 
 public void setY(float y){ this.y = y; }
 
 public float getX(){ return this.x; }
 
 public float getY(){ return this.y; }

}
//Create a radial force field that attracts equally from all points
//towards a single point

class RadialField extends ForceField {
  Point center; //where the force is coming from
  float mag; //the magnitude of the froce
  boolean isMoving = false; //if the force is clicked on to move

  RadialField(Point center, float mag) {
    this.center = new Point(center.getX(),center.getY());
    this.mag = mag;
  }

  public Point getVelocity(Point point) {
    float dx = this.center.getX() - point.getX(); //change in x
    float dy = this.center.getY() - point.getY(); //change in y
    float angle = atan(dy/dx); //angle between field source and particle
    
    
    //if dx is negative, we want to negate the return values
    if (dx<0) {
      return new Point(-mag*cos(angle), -mag*sin(angle));
    } else { //return normal values
      return new Point(mag*cos(angle), mag*sin(angle));
    }
  }

  public void show() {
    //if is clicked, move to mouse 
    if (isLeftClicked()) {
      isMoving = true;
    }
    if(!mousePressed){
     isMoving = false; 
    }
    if(isMoving){
     center.setX(mouseX);
     center.setY(mouseY); 
    }

    //draw identifiers
    fill(0,200);
    ellipse(center.getX(), center.getY(), 50, 50); 
    fill(255);
    
    textAlign(CENTER);
    text("R\n" + mag, center.getX(), center.getY());
  }

  public boolean isLeftClicked() {
    if (isOver() && mousePressed && mouseButton == LEFT) {
      return true;
    }
    return false;
  }
  
  public boolean isRightClicked() {
    if (isOver() && mousePressed && mouseButton == RIGHT) {
      return true;
    }
    return false;
  }

  public boolean isOver() {
    if (dist(center.getX(), center.getY(),mouseX,mouseY) < 25) {
      return true;
    }
    return false;
  }
}
class StringInput {
  String[] options; //the options we cycle through
  int index = 0; //start at index 0
  float x, y; //x and y coords of the center
  String name; //name of the data field
  Button right, left; //buttons to cycle through the options
  boolean hasBeenClicked = false; //by default, neither button is clicked

  StringInput(String name, String[] options, float x, float y) {
    this.name = name;
    this.options = options;
    this.x = x;
    this.y = y;
    this.left = new Button(x-50, y, 25, 25, "<");
    this.right = new Button(x+50, y, 25, 25, ">");
  }

  public void show() {

    //if right is clicked, we cycle to the right of the list and loop if we go past the end
    if (right.isClicked() && !hasBeenClicked) {
      index++; 
      if (index >= options.length) {
        index = 0;
      }
      hasBeenClicked = true;
    }

    //if left is clicked, we cycle to the left of the list and loop if we go past the beginning
    if (left.isClicked() && !hasBeenClicked) {
      index--; 
      if (index < 0) {
        index = options.length-1;
      }
      hasBeenClicked = true;
    }

    //if neither is clicked, we reset hasBeenClicked
    if (!right.isClicked() && !left.isClicked()) {
      hasBeenClicked = false;
    }

    //display data
    left.show();
    right.show();
    textFont(createFont("Tahoma", width/50));
    textAlign(CENTER, CENTER);
    text(options[index], x, y);
    text(name, x, y-height/40);
  }

  public String getData() {
    return this.options[index];
  }
}
class SystemSettings{
 Point center;
 float maxXVelocity, maxYVelocity, minXVelocity, minYVelocity;
 int particleCount;
 String particleType;
 
 SystemSettings(Point center, int particleCount, float maxXVelocity, float minXVelocity, float maxYVelocity, float minYVelocity, String particleType){
   this.center = center;
   this.particleCount = particleCount;
   this.maxXVelocity = maxXVelocity;
   this.minXVelocity = minXVelocity;
   this.maxYVelocity = maxYVelocity;
   this.minYVelocity = minYVelocity;
   this.particleType = particleType;
 }
 
 SystemSettings(SystemSettings dummy){
   this.center = dummy.center;
   this.particleCount = dummy.particleCount;
   this.maxXVelocity = dummy.maxXVelocity;
   this.minXVelocity = dummy.minXVelocity;
   this.maxYVelocity = dummy.maxYVelocity;
   this.minYVelocity = dummy.minYVelocity;
   this.particleType = dummy.particleType;
 }
 
 public Point center(){ return this.center; }
 public int particleCount(){ return this.particleCount; }
 public float maxXVelocity(){ return this.maxXVelocity; }
 public float minXVelocity(){ return this.minXVelocity; }
 public float maxYVelocity(){ return this.maxYVelocity; }
 public float minYVelocity(){ return this.minYVelocity; }
 public String particleType(){ return this.particleType; }
}
class UI {
  ArrayList<String> buttonNames = new ArrayList<String>(); //names of the buttons
  ArrayList<Button> buttons = new ArrayList<Button>(); //the button objects to be displayed on the ui
  String[] directionOptions = {"DOWN", "UP", "LEFT", "RIGHT"}; //options for gravity direction
  String[] particleTypeOptions = {"CIRCLE", "LINE"}; //options for particle types

  //the fields we need for generating gravity fields
  DataInput gravMag = new DataInput("Gravity Strength", 1, width/10, 7.8f*height/9, 10, -10, 1);
  StringInput direction = new StringInput("Gravity Direction", directionOptions, width/10, 8.2f*height/9);

  //the fields for radial fields

  DataInput radMag = new DataInput("Radial Strength", 1, 3*width/10, 7.8f*height/9, 10, -10, 1);

  //the fields for newton fields
  
  DataInput newtMag = new DataInput("Newton Strength",1, 5*width/10, 7.8f*height/9, 10, -10, 1);

  //the fields we need for generating particle systems
  DataInput numberOfParticles = new DataInput("Particle Count", 500, 7*width/10, 7.8f*height/9, 1000, 0, 50);
  StringInput particleType = new StringInput("Particle Type", particleTypeOptions, 9*width/10, 7.8f*height/9);
  DataInput maxXVel = new DataInput("Max X Velocity", 1, 9*width/10, 8.2f*height/9, 10, -10, 1);
  DataInput minXVel = new DataInput("Min X Velocity", -1, 7*width/10, 8.2f*height/9, 10, -10, 1);
  DataInput maxYVel = new DataInput("Max Y Velocity", 1, 9*width/10, 8.6f*height/9, 10, -10, 1);
  DataInput minYVel = new DataInput("Min Y Velocity", -1, 7*width/10, 8.6f*height/9, 10, -10, 1);

  //default
  UI() {
  };

  //generate UI based on the buttons given
  UI(ArrayList<String> buttonNames) {
    this.buttonNames  = buttonNames;
    initializeButtons();
  }

  public void show() {
    //draw background
    noStroke();
    rectMode(CENTER);
    fill(0xff7A9BB4);
    rect(width/2, 8*height/9, width, 2*height/9 + 10);

    //show buttons
    for (int i = 0; i<buttons.size(); i++) {
      buttons.get(i).show();
    }

    //show data fields
    gravMag.show();
    direction.show();

    radMag.show();

    newtMag.show();

    numberOfParticles.show();
    particleType.show();
    maxXVel.show();
    minXVel.show();
    maxYVel.show();
    minYVel.show();
  }

  public void initializeButtons() {
    int num = buttonNames.size();
    int c = width/(100*num);

    //some magic numbers, used to give proper alignment of the buttons
    float xL = width-2*c;
    float dX = xL/(num);
    float dY = 7.25f*height/9;
    float dW = dX - num*c;
    float dH = (height/18);

    c += dX/2;
    for (int i = 0; i < num; i++) {
      buttons.add(new Button(c, dY, dW, dH, buttonNames.get(i)));
      c += dX;
    }
  }

  //returns name of clicked button to main, so we can perform the appropriate action
  public String getClickedButton() {
    for (int i = 0; i<buttons.size(); i++) {
      if (buttons.get(i).isClicked()) {
        return buttons.get(i).name;
      }
    }
    return "none";
  }
}
  public void settings() {  size(1000, 1250); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "ParticleSimulator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
