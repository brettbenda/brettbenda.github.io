import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class mandelbrot extends PApplet {

/*
Made by Brett Benda in 2017
*/

int imageNum = 1;
double zoom = 4;
double xDisplacement = 0;
double yDisplacement = 0;
boolean isMoving = false;
double savedXDis;//xDisplacement at start of movement
double savedYDis;//yDisplacement at start of movement
double tempDX;//temp change in x, based on zoom
double tempDY;//temp change in y, based on zoom
double initX;//x pos when you first click
double initY;//y pos when you first click
double currX;//x pos after you click, but still have mouse pressed
double currY;//y pos after you click, but still have mouse pressed

DataInput iterations;

public void setup() {
  
  background(255);
  iterations = new DataInput("Max Iterations",50,1100,100,1000,0,5);
}

public void draw() {
  background(255);
  updateZoomAndTranslation();
  drawMandelbrot(zoom, xDisplacement, yDisplacement, (int)iterations.getData());
  iterations.show();
}

public void mouseWheel(MouseEvent event){
  if(event.getCount()<0){
    zoom*=0.9f;
  }
  if(event.getCount()>0){
    zoom*=1.1f;
  }
}

public void updateZoomAndTranslation() {
  if (mousePressed) {
    if (!isMoving) {
      isMoving = true;
      initX = mouseX;
      initY = mouseY;
      savedXDis = xDisplacement;
      savedYDis = yDisplacement;
    }
    if (isMoving) {
      currX = mouseX;
      currY = mouseY;
      tempDX = (double)(initX-currX)/width*zoom; 
      tempDY = (double)(initY-currY)/height*zoom;
      xDisplacement = savedXDis + tempDX;
      yDisplacement = savedYDis + tempDY;
    }
  } else {
    isMoving = false;
  }
}

public void drawMandelbrot(double xAxisLength, double xDisplacement, double yDisplacement, int iterations) {
  //load pixels so we can modify them
  loadPixels();

  //using HSB for coloring
  colorMode(HSB);

  //we want the y-axis to be proportional to the x-axis
  double yAxisHeight = (xAxisLength * height)/width;

  //minimun (starting) values
  //and how much we need to increase them by each iterations
  double xMinimum = -xAxisLength/2 + xDisplacement;
  double dX = xAxisLength/width;
  double yMinimum = -yAxisHeight/2 + yDisplacement;
  double dY = yAxisHeight/height;

  double y = yMinimum;//start at minumum x-value

  //increment across the row
  for (int i = 0; i<height; i++) {

    double x = xMinimum;//start at minimum y-value;

    //increment down the column;
    for (int j = 0; j<width; j++) {

      double a = x;//real part is x

      double b = y;//imaginary part is y

      int n = 0; //start at iteration 0

      while (n<iterations) {
        double aSquared = a*a;
        double bSquared = b*b;
        double twoAB = 2*a*b;

        //new parts are determined by expansion 
        //(a+bi)^2 == a^2 - b^2 + 2ab
        a = aSquared - bSquared + x;
        b = twoAB + y;

        //if value of new
        if (Math.sqrt(a*a+b*b)>4) {
          break;
        }
        n++;
      }

      if (n == iterations) {
        pixels[j+i*width] = 0xff000000;
      } else {
       float hue = 5*n;
        if (hue > 255) {
          hue = hue%255;
        }
        pixels[j+i*width] = color(hue, 255, 255);
      }

      x+=dX;
    }
    y+=dY;
  }

  updatePixels();
}
class Button {
  float x;
  float y;
  float buttonWidth;
  float buttonHeight;
  String name;

  Button(float x, float y, float buttonWidth, float buttonHeight, String name) {
    this.x=x;
    this.y=y;
    this.buttonWidth=buttonWidth;
    this.buttonHeight=buttonHeight;
    this.name = name;
  }

  public void show() {
    rectMode(CENTER);
    if (isClicked()) {
      fill(200);
    } else {
      fill(225);
    }
    stroke(100);
    rect(x, y, buttonWidth, buttonHeight, 10);
    fill(0);
    textFont(createFont("Tahoma", buttonHeight/2));
    textAlign(CENTER);
    text(name,x,y+buttonHeight/5);
  }

  public boolean isClicked() {
    if (mousePressed && isOver()) {
      return true;
    }
    return false;
  }

  public boolean isOver() {
    if (mouseX > x - buttonWidth/2 && mouseX < x + buttonWidth/2) {
      if (mouseY > y - buttonHeight/2 && mouseY < y + buttonHeight/2) {
        return true;
      }
    }
    return false;
  }
}
class DataInput {
  float data = 0; //current value that can be retrieved
  float x, y, upperBound, lowerBound, increment; //x coord of center, y coord of center, max value, min value, value used as increment
  String name; //name of the field
  Button upper, lower; //buttons to modify the current data
  boolean hasBeenClicked = false; //by default, neither button is clicked

  DataInput(String name, float defaultVal, float x, float y, float upperBound, float lowerBound, float increment) {
    this.name = name;
    this.data = defaultVal;
    this.x = x;
    this.y = y;
    this.upperBound = upperBound;
    this.lowerBound = lowerBound;
    this.lower = new Button(x-50,y,25,25,"-");
    this.upper = new Button(x+50,y,25,25,"+");
    this.increment = increment;
  }
  
  public void show(){
   //increment data by the given increment value if the right arrow is selected
   if(upper.isClicked() && data < upperBound && !hasBeenClicked){
    data+=increment; 
    hasBeenClicked = true;
   }
   //decrement data by the given increment value if the left arrow is selected
   if(lower.isClicked() && data > lowerBound && !hasBeenClicked){
    data-= increment; 
    hasBeenClicked = true;
   }
   
   //if neither button is clicked, neither has been clicked
   if(!upper.isClicked() && !lower.isClicked()){
    hasBeenClicked = false; 
   }
   
   //display data
   lower.show();
   upper.show();
   fill(255);
   textFont(createFont("Tahoma", width/50));
   textAlign(CENTER,CENTER);
   if(data%1==0){
     text((int)data,x,y);
   }else{
     text(data,x,y);
   }
   text(name,x,y-height/20);
  }
  
  
  //return the data currently being stored
  public float getData(){
   return this.data; 
  }
}
  public void settings() {  size(1200, 675); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "mandelbrot" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
