Made by Brett Benda in 2017.

This application displays Julia Sets.

You can use your mouse to navigate by clicking and dragging to move, 
and using the mouse wheel to zoom.

You can change the maximum number of iterations. A higher number of iterations
will decrease performance, but increase accuracy. The minimum number of 
iterations is 0, and the maximum is 1000 (although 1000 is not recommended).

Changing the real and imaginary parts will modify the set.
Each part has a minimum of -2, and a maximum of 2.