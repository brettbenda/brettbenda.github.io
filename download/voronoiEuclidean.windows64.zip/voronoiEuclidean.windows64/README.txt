Made by Brett Benda in 2017

You can use this application to create Voronoi Diagrams.
Use the mouse to move points, and the button to create a new point.